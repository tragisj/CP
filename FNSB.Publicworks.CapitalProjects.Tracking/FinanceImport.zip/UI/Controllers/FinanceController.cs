﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FNSB.Projects.UI.Models;
using FNSB.PW.Finance.Import.Domain;
using FNSB.PW.Finance.Import.Domain.Helpers;

namespace FNSB.Projects.UI.Controllers
{
    public class FinanceController : Controller
    {

        private PubworksModel db = new PubworksModel();

        // GET: Finance
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Import()
        {

            return View();

        }

        public PartialViewResult ActiveGlKeys(int projectId)
        {

            var data = db.Projects.Where(k => k.PPM_Recordid == projectId);


            var data2 = db.Funds.Where(k => k.ppm_recordid == projectId).ToList();



            return PartialView(data2);
        }


    }
}