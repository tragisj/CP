namespace FNSB.Projects.UI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Publicworks.ArchitectEngineers")]
    public partial class ArchitectEngineer
    {
        [Key]
        public int recordid { get; set; }

        [StringLength(50)]
        public string firstname { get; set; }

        [StringLength(50)]
        public string lastname { get; set; }

        public int? order { get; set; }
    }
}
