namespace FNSB.Projects.UI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Publicworks.Consultants")]
    public partial class Consultant
    {
        [Key]
        public int ppc_recordid { get; set; }

        [StringLength(255)]
        public string consultantname { get; set; }
    }
}
