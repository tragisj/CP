namespace FNSB.Projects.UI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Publicworks.ProjectTypes")]
    public partial class ProjectType
    {
        [Key]
        public int ppt_recordid { get; set; }

        [StringLength(255)]
        public string category { get; set; }
    }
}
