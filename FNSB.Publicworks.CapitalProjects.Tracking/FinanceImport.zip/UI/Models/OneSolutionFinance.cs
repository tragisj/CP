﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.EnterpriseServices.Internal;
using System.Linq;
using System.Web;
using FNSB.PW.Finance.Import.Data;

namespace FNSB.Projects.UI.Models
{
    [Table("Publicworks.OneSolutionFinance")]
    public partial class OneSolutionFinance
    {   
        
        public int Id { get; set; }

        [Key]
        public string GlKey { get; set; }

        public int ProjectId { get; set; }


        
    }
}