﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FNSB.Projects.UI.Models
{
    public class ManagerProjectViewModel
    {
        public List<Project> ProjectProfileObject { get; set; }
        public ProjectManager ProjectManagerProfileObject { get; set; }
    }
}