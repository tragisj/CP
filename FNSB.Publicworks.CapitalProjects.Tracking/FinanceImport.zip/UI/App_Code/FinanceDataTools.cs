﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FNSB.Projects.UI
{
    public class FinanceDataTools
    {

        FinanceDataTools()
        {
            


        }

    }
}