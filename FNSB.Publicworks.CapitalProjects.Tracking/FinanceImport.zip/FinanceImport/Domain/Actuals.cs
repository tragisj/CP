﻿namespace FNSB.PW.Finance.Import.Domain
{
   public class Actual
   {
        public decimal Actuals01 { get; set; }
        public decimal Actuals02 { get; set; }
        public decimal Actuals03 { get; set; }
        public decimal Actuals04 { get; set; }
        public decimal Actuals05 { get; set; }
        public decimal Actuals06 { get; set; }
        public decimal Actuals07 { get; set; }
        public decimal Actuals08 { get; set; }
        public decimal Actuals09 { get; set; }
        public decimal Actuals10 { get; set; }
        public decimal Actuals11 { get; set; }
        public decimal Actuals12 { get; set; }
        public decimal Actuals13 { get; set; }
        public decimal Actuals14 { get; set; }
    }
}
