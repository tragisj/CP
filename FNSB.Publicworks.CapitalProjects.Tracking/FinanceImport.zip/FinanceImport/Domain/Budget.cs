﻿namespace FNSB.PW.Finance.Import.Domain
{
    public class Budget
    {
        public decimal Budget01 { get; set; }
        public decimal Budget02 { get; set; }
        public decimal Budget03 { get; set; }
        public decimal Budget04 { get; set; }
        public decimal Budget05 { get; set; }
        public decimal Budget06 { get; set; }
        public decimal Budget07 { get; set; }
        public decimal Budget08 { get; set; }
        public decimal Budget09 { get; set; }
        public decimal Budget10 { get; set; }
        public decimal Budget11 { get; set; }
        public decimal Budget12 { get; set; }
    }
}
