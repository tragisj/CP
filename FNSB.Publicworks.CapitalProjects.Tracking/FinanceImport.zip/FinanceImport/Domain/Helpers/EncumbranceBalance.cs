﻿

namespace FNSB.PW.Finance.Import.Domain.Helpers
{
    public class EncumbranceBalance
    {
        public decimal Amount { get; set; }

    }
}
