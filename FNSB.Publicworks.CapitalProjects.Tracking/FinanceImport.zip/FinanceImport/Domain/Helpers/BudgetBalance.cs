﻿namespace FNSB.PW.Finance.Import.Domain.Helpers
{
    public class BudgetBalance
    {
        public string BudgetVersion { get; set; }
        public int FiscalYear { get; set; }
        public decimal Amount { get; set; }
    }
}
