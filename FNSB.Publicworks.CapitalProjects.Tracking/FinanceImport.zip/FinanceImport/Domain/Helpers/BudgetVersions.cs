﻿namespace FNSB.PW.Finance.Import.Domain.Helpers
{
    public class BudgetVersions
    {
        public string Code { get; set; }
        public string Desc { get; set; }
        public string Calc { get; set; }
        public short Index { get; set; }
    }
}
