﻿namespace FNSB.PW.Finance.Import.Domain
{
    public class Encumbrances
    {
        public decimal En01 { get; set; }
        public decimal En02 { get; set; }
        public decimal En03 { get; set; }
        public decimal En04 { get; set; }
        public decimal En05 { get; set; }
        public decimal En06 { get; set; }
        public decimal En07 { get; set; }
        public decimal En08 { get; set; }
        public decimal En09 { get; set; }
        public decimal En10 { get; set; }
        public decimal En11 { get; set; }
        public decimal En12 { get; set; }
        public decimal En13 { get; set; }
        public decimal En14 { get; set; }

        public enum @OffsetField
        {
            En01 = 1,
            En02,
            En03,
            En04,
            En05,
            En06,
            En07,
            En08,
            En09,
            En10,
            En11,
            En12
        }
    }
}
